import cv2 as cv
import os

# Directorio base compatible con Windows y Linux
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "pruebacaras")

NOMBRE_PERSONA = input("Ingresa el nombre de la persona a registrar: ").strip().lower()

persona_dir = os.path.join(DATASET_PATH, NOMBRE_PERSONA)
if not os.path.exists(persona_dir):
    os.makedirs(persona_dir)
    print(f"Carpeta creada: {persona_dir}")
else:
    print(f"Añadiendo fotos a la carpeta existente: {persona_dir}")

# Intento de carga del clasificador Haar
cascade_file = "haarcascade_frontalface_alt2.xml"
cascade_path = os.path.join(BASE_DIR, cascade_file)

if os.path.exists(cascade_path):
    cascade = cv.CascadeClassifier(cascade_path)
else:
    # Si no existe localmente, intenta usar la ruta interna de opencv
    cv_data_path = getattr(cv, 'data', None)
    if cv_data_path is not None:
        cascade = cv.CascadeClassifier(cv.data.haarcascades + cascade_file)
    else:
        cascade = cv.CascadeClassifier()

if cascade.empty():
    print(f"\n[ERROR CRÍTICO]: No se pudo cargar el archivo '{cascade_file}'.")
    print(f"Por favor descarga '{cascade_file}' y colócalo en:")
    print(f"{BASE_DIR}")
    exit()

cap = cv.VideoCapture(0)
count = 0
LIMITE_FOTOS = 60

print("\nPresiona ESC para cancelar o espera a que se tomen las capturas automáticamente.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error al acceder a la cámara.")
        break

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    rostros = cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in rostros:
        cv.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        
        roi = gray[y:y + h, x:x + w]
        roi_resized = cv.resize(roi, (100, 100), interpolation=cv.INTER_CUBIC)

        count += 1
        file_path = os.path.join(persona_dir, f"rostro_{count:03d}.jpg")
        cv.imwrite(file_path, roi_resized)

        cv.putText(frame, f"Captura {count}/{LIMITE_FOTOS}", (x, y - 10),
                   cv.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    cv.imshow("Capturando Dataset", frame)

    if cv.waitKey(100) == 27 or count >= LIMITE_FOTOS:
        break

cap.release()
cv.destroyAllWindows()
print(f"\n¡Proceso completado! Se guardaron {count} imágenes en '{persona_dir}'.")