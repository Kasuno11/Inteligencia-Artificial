import cv2 as cv
import os

data_set = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pruebacaras")

# Obtener los nombres de las personas en el mismo orden que en el entrenamiento
faces = sorted(
    d for d in os.listdir(data_set)
    if os.path.isdir(os.path.join(data_set, d))
)

# Cargar el reconocedor de caras y el modelo entrenado
face_recognizer = cv.face.EigenFaceRecognizer_create()

if not os.path.exists("modelo_eigenfaces.xml"):
    print("Error: El archivo 'modelo_eigenfaces.xml' no existe. Entrena el modelo primero.")
    exit()

face_recognizer.read("modelo_eigenfaces.xml")

# Cargar Haar Cascade para detección previa
cascade_path = "haarcascade_frontalface_alt2.xml"
cascade = cv.CascadeClassifier(cascade_path)
if cascade.empty():
    cascade = cv.CascadeClassifier(cv.data.haarcascades + "haarcascade_frontalface_alt2.xml")

cap = cv.VideoCapture(0)
if not cap.isOpened():
    print("Error al abrir la cámara web.")
    exit()

THRESHOLD = 2800  # Umbral de distancia para Eigenfaces (Ajustar empíricamente)

print("Iniciando reconocimiento en vivo. Presiona ESC para salir.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    rostros = cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=3)

    for (x, y, w, h) in rostros:
        # Extraer ROI y redimensionarla al estándar de entrenamiento (100x100)
        roi = cv.resize(gray[y:y + h, x:x + w], (100, 100), interpolation=cv.INTER_CUBIC)
        
        # Realizar la predicción
        label_id, confidence = face_recognizer.predict(roi)

        if confidence < THRESHOLD and label_id < len(faces):
            name = faces[label_id]
            color = (0, 255, 0)  # Verde
            text = f"{name} ({confidence:.0f})"
        else:
            color = (0, 0, 255)  # Rojo
            text = f"Desconocido ({confidence:.0f})"

        # Dibujar rectángulos e información
        cv.putText(frame, text, (x, y - 12), cv.FONT_HERSHEY_SIMPLEX,
                   0.7, color, 2, cv.LINE_AA)
        cv.rectangle(frame, (x, y), (x + w, y + h), color, 2)

    cv.imshow("Eigenfaces - Reconocimiento en Vivo", frame)

    if cv.waitKey(1) == 27:  # Tecla ESC para salir
        break

cap.release()
cv.destroyAllWindows()