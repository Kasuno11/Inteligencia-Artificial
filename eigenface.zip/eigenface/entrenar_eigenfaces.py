import cv2 as cv
import numpy as np
import os

data_set = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pruebacaras")

if not os.path.exists(data_set):
    print(f"Error: La ruta '{data_set}' no existe. Ejecuta primero el script de captura.")
    exit()

faces = sorted([d for d in os.listdir(data_set) if os.path.isdir(os.path.join(data_set, d))])
print("Personas encontradas:", faces)

if not faces:
    print("No se encontraron carpetas de personas dentro del dataset.")
    exit()

labels = []
faces_data = []
label = 0

for person in faces:
    person_path = os.path.join(data_set, person)
    count_imgs = 0
    
    for img_name in os.listdir(person_path):
        img_path = os.path.join(person_path, img_name)
        img = cv.imread(img_path, 0)  # Cargar directamente en escala de grises
        
        if img is None:
            continue
        
        # Asegurar que la imagen mida exactamente 100x100
        if img.shape != (100, 100):
            img = cv.resize(img, (100, 100), interpolation=cv.INTER_CUBIC)

        labels.append(label)
        faces_data.append(img)
        count_imgs += 1

    print(f"  {person} (label={label}): {count_imgs} imágenes procesadas")
    label += 1

print("\nEntrenando EigenFaceRecognizer...")
face_recognizer = cv.face.EigenFaceRecognizer_create()
face_recognizer.train(faces_data, np.array(labels))

# Guardar el modelo entrenado
modelo_out = "modelo_eigenfaces.xml"
face_recognizer.write(modelo_out)
print(f"¡Modelo escrito con éxito en: {modelo_out}!")