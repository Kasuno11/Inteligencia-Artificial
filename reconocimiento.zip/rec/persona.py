import os
import cv2 as cv

# Configuración por persona
persona_nombre = 'persona_1'  # Cambiar para cada persona (persona_1, persona_2, ...)
label_id = 0                  # ID único para cada persona (0, 1, 2, 3, 4)
max_imagenes = 100            # Cantidad de imágenes a capturar

dataset_path = f'/home/likcos/pruebacaras/dataset/{label_id}_{persona_nombre}'
os.makedirs(dataset_path, exist_ok=True)

rostro_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_alt2.xml')
cap = cv.VideoCapture('/home/likcos/x1/compux1/dwhelper/caras.mp4') # o 0 si usas cámara web

count = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    rostros = rostro_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in rostros:
        img_rostro = gray[y:y+h, x:x+w]
        imgr = cv.resize(img_rostro, (150, 150))
        
        count += 1
        img_name = f"{dataset_path}/rostro_{count}.jpg"
        cv.imwrite(img_name, imgr)

        # Dibujar recuadro verde para confirmar captura
        cv.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv.putText(frame, f"Captura {count}/{max_imagenes}", (x, y - 10),
                   cv.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    cv.imshow('Capturando dataset', frame)

    k = cv.waitKey(1)
    if k == 27 or count >= max_imagenes:
        break

cap.release()
cv.destroyAllWindows()
print(f"Dataset completado para {persona_nombre}")