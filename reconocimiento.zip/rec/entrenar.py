import os
import cv2 as cv
import numpy as np

base_path = r'C:\Users\kevin\OneDrive\Desktop\rec'
dataset_path = os.path.join(base_path, 'dataset')
cascade_path = os.path.join(base_path, 'haarcascade_frontalface_default.xml')

face_cascade = cv.CascadeClassifier(cascade_path)

# Ordenar alfabéticamente para mantener coincidencia estricta de IDs
people_list = sorted([d for d in os.listdir(dataset_path) if os.path.isdir(os.path.join(dataset_path, d))])

print('Lista de personas ordenadas:')
for idx, name in enumerate(people_list):
    print(f"  ID {idx} -> {name}")

labels = []
faces_data = []

for label, name_dir in enumerate(people_list):
    person_path = os.path.join(dataset_path, name_dir)

    for file_name in os.listdir(person_path):
        image_path = os.path.join(person_path, file_name)
        image = cv.imread(image_path)
        if image is None:
            continue

        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        rostros = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5)

        for (x, y, w, h) in rostros:
            rostro_roi = gray[y:y+h, x:x+w]
            rostro_roi = cv.resize(rostro_roi, (150, 150))
            faces_data.append(rostro_roi)
            labels.append(label)

print(f"\nTotal de rostros extraídos para entrenamiento: {len(faces_data)}")

if len(faces_data) > 0:
    print("Entrenando el modelo LBPH...")
    face_recognizer = cv.face.LBPHFaceRecognizer_create()
    face_recognizer.train(faces_data, np.array(labels))

    model_path = os.path.join(base_path, 'modeloLBPH.xml')
    face_recognizer.write(model_path)
    print(f"Modelo guardado exitosamente en: {model_path}")