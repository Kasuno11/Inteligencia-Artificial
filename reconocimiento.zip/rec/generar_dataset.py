import os
import shutil
import urllib.request
import cv2 as cv
import numpy as np

base_path = r'C:\Users\kevin\OneDrive\Desktop\rec'
dataset_path = os.path.join(base_path, 'dataset')

# 5 personas con rostros públicos distintos
personas_urls = {
    'Persona1_Obama': 'https://raw.githubusercontent.com/ageitgey/face_recognition/master/examples/obama.jpg',
    'Persona2_Biden': 'https://raw.githubusercontent.com/ageitgey/face_recognition/master/examples/biden.jpg',
    'Persona3_Lena': 'https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg',
    'Persona4_Messi': 'https://raw.githubusercontent.com/opencv/opencv/master/samples/data/messi5.jpg',
    'Persona5_Miranda': 'https://raw.githubusercontent.com/ageitgey/face_recognition/master/examples/lin-manuel-miranda.png'
}

print("Limpiando dataset anterior...")
if os.path.exists(dataset_path):
    shutil.rmtree(dataset_path) # Borrar basuras o fotos mezcladas anteriores

os.makedirs(dataset_path, exist_ok=True)
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

for persona, url in personas_urls.items():
    persona_dir = os.path.join(dataset_path, persona)
    os.makedirs(persona_dir, exist_ok=True)
    
    print(f"\nDescargando y procesando {persona}...")
    temp_img = os.path.join(persona_dir, 'base.jpg')
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req) as response, open(temp_img, 'wb') as out_file:
            out_file.write(response.read())
            
        base_img = cv.imread(temp_img)
        if base_img is not None:
            h, w = base_img.shape[:2]
            center = (w // 2, h // 2)

            count = 0
            # Generar 15 variaciones geométricas reales (rotaciones, zoom, reflejos)
            for angle in [-12, -6, 0, 6, 12]:
                for scale in [0.95, 1.0, 1.05]:
                    count += 1
                    # Matriz de rotación y escala
                    M = cv.getRotationMatrix2D(center, angle, scale)
                    img_rot = cv.warpAffine(base_img, M, (w, h), borderMode=cv.BORDER_REPLICATE)

                    # Ajuste leve de brillo/contraste
                    alpha = 0.9 + (count * 0.01)
                    beta = (count % 5) * 4 - 10
                    img_var = cv.convertScaleAbs(img_rot, alpha=alpha, beta=beta)

                    # Voltear horizontalmente en alternancia
                    if count % 2 == 0:
                        img_var = cv.flip(img_var, 1)

                    cv.imwrite(os.path.join(persona_dir, f"foto_{count}.jpg"), img_var)

            print(f" -> {count} imágenes generadas con ángulos y zooms distintos para {persona}")

        if os.path.exists(temp_img):
            os.remove(temp_img)

    except Exception as e:
        print(f" -> Error con {persona}: {e}")

print("\n¡Dataset regenerado desde cero con 5 rostros y variaciones de ángulo exitosamente!")