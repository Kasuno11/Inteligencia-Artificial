import os
import cv2 as cv
import tkinter as tk
from tkinter import filedialog

base_path = r'C:\Users\kevin\OneDrive\Desktop\rec'
dataset_path = os.path.join(base_path, 'dataset')
cascade_path = os.path.join(base_path, 'haarcascade_frontalface_default.xml')

root = tk.Tk()
root.withdraw()

print("Selecciona una imagen en la ventana emergente...")
ruta_imagen = filedialog.askopenfilename(
    title="Selecciona la imagen para el reconocimiento",
    filetypes=[("Archivos de Imagen", "*.jpg *.jpeg *.png *.bmp")]
)

if not ruta_imagen:
    print("No se seleccionó ninguna imagen.")
    exit()

# Orden estricto idéntico al entrenamiento
nombres = sorted([d for d in os.listdir(dataset_path) if os.path.isdir(os.path.join(dataset_path, d))])

face_recognizer = cv.face.LBPHFaceRecognizer_create()
face_recognizer.read(os.path.join(base_path, 'modeloLBPH.xml'))
face_cascade = cv.CascadeClassifier(cascade_path)

frame = cv.imread(ruta_imagen)

if frame is None:
    print("Error al abrir la imagen seleccionada.")
else:
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    rostros = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5)

    for (x, y, w, h) in rostros:
        rostro_roi = gray[y:y+h, x:x+w]
        rostro_roi = cv.resize(rostro_roi, (150, 150))

        label, confidence = face_recognizer.predict(rostro_roi)

        # Umbral aceptable para LBPH (< 100)
        if confidence < 100:
            nombre_persona = nombres[label]
            color = (0, 255, 0) # Verde
        else:
            nombre_persona = 'Desconocido'
            color = (0, 0, 255) # Rojo

        cv.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv.putText(frame, f"{nombre_persona} ({int(confidence)})", (x, y - 10),
                   cv.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

    cv.imshow('Resultado del Reconocimiento', frame)
    cv.waitKey(0)
    cv.destroyAllWindows()